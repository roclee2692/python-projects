import pandas as pd, numpy as np, joblib, json, pyarrow.parquet as pq
df = pd.read_csv(r"D:\python-projects\q1_daily_merged.csv", parse_dates=["date"]).sort_values("date")

# 按之前脚本**同样的步骤**造滞后/累计特征……
# 省略： met_cols 清洗、lag、RRR_sum3/7、diff1_lag1 —— 保证和训练时一模一样
# 最终得到 feats 列表、target = 'sm5'

Xy = df.dropna(subset=feats+[target]).copy()
pq.write_table(pa.Table.from_pandas(Xy[feats+[target]]),
               r"D:\python-projects\q1_dataset.parquet")
print("✅ 已导出 q1_dataset.parquet：", Xy.shape)
